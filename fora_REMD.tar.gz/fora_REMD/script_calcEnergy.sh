#!/bin/bash 

module load gcc/7.4 
source /scratch/covidufscar/weverson.gomes3/gromacs_19/bin/GMXRC


fullPathFiles=$(find . -type f -name "*.edr" | sort)
rootPath=`pwd`
GMX=gmx_19

echo "ALL FILES: " ${fullPathFiles}

folder=data    

mkdir ${folder}
property="Enthalpy"

n=0
for d in ${fullPathFiles}; 
do
    dirPath=$(dirname "${d}")
    fileName=$(basename -- "${d}")
    outFilename="${fileName%.*}"
    outFilename=traj_comp

    echo "$dirPath" "${outFilename}"; 
    
    cd ${dirPath}
    echo "enthalpy" | $GMX energy -f ${fileName} -o ${rootPath}/${folder}/${n}.${property} -xvg none
    $GMX distance -s topol.tpr -f ${outFilename}.xtc -select 'com of group "r_1" plus com of group "r_10"' -xvg none -n ${rootPath}/residues1_10.ndx -oav ${rootPath}/$folder/${n}.dist
    echo -e "protein\n protein\n\n" | $GMX hbond -s topol.tpr -f ${outFilename}.xtc -num ${rootPath}/$folder/${n}.hbond_protein_protein -nthreads 24 -xvg none
    echo -e "protein\n water\n\n" | $GMX hbond -s topol.tpr -f ${outFilename}.xtc -num ${rootPath}/$folder/${n}.hbond_protein_water -nthreads 24 -xvg none

    cd ${rootPath}
    
    n=$((n+1))
done

